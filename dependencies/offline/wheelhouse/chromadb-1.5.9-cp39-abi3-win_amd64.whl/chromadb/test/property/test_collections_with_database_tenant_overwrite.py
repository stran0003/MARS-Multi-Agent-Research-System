from typing import Dict, Optional, Tuple
from overrides import overrides
from hypothesis.stateful import (
    initialize,
    invariant,
    rule,
    run_state_machine_as_test,
)

import uuid
import logging
import os
import pytest
from chromadb.api import AdminAPI, ServerAPI
from chromadb.api.client import AdminClient, Client
from chromadb.config import Settings, System
from chromadb.test.conftest import (
    ClientFactories,
    DEFAULT_MCMR_DATABASE,
    fastapi_fixture_admin_and_singleton_tenant_db_user,
    MULTI_REGION_TOPOLOGY,
    multi_region_test,
    NOT_CLUSTER_ONLY,
)
from chromadb.test.property.test_collections_with_database_tenant import (
    TenantDatabaseCollectionStateMachine,
)
import chromadb.test.property.strategies as strategies
import numpy
import chromadb.api.types as types

# See conftest.py
SINGLETON_TENANT = "singleton_tenant"
SINGLETON_DATABASE_NAME = "singleton_database"


def singleton_database_name(database_name: str) -> str:
    if database_name == DEFAULT_MCMR_DATABASE:
        return f"{MULTI_REGION_TOPOLOGY}+{SINGLETON_DATABASE_NAME}"
    return SINGLETON_DATABASE_NAME


class SingletonTenantDatabaseCollectionStateMachine(
    TenantDatabaseCollectionStateMachine
):
    singleton_client: Client
    singleton_admin_client: AdminAPI
    root_client: Client
    root_admin_client: AdminAPI
    singleton_database: str

    def __init__(
        self,
        singleton_client: Client,
        root_client: Client,
        client_factories: ClientFactories,
        database_name: str,
    ) -> None:
        super().__init__(client_factories, database_name=database_name)
        self.root_client = root_client
        self.root_admin_client = self.admin_client

        self.singleton_database = singleton_database_name(database_name)
        self.singleton_client = singleton_client
        self.singleton_admin_client = AdminClient.from_system(singleton_client._system)

    @initialize()
    def initialize(self) -> None:
        # Make sure we're back to the root client and admin client before
        # doing reset/initialize things.
        self.client = self.root_client
        self.admin_client = self.root_admin_client

        super().initialize()

        self.root_admin_client.create_tenant(SINGLETON_TENANT)
        self.root_admin_client.create_database(
            self.singleton_database, SINGLETON_TENANT
        )

        self.set_tenant_model(SINGLETON_TENANT, {})
        self.set_database_model_for_tenant(
            SINGLETON_TENANT, self.singleton_database, {}
        )

    @invariant()
    def check_api_and_admin_client_are_in_sync(self) -> None:
        if self.client == self.singleton_client:
            assert self.admin_client == self.singleton_admin_client
        else:
            assert self.admin_client == self.root_admin_client

    @rule()
    def change_clients(self) -> None:
        if self.client == self.singleton_client:
            self.client = self.root_client
            self.admin_client = self.root_admin_client
            # When switching back to root, restore the previous tenant/database context
            from chromadb.config import DEFAULT_TENANT

            self.client.set_tenant(DEFAULT_TENANT, self.effective_default_database)
            self.curr_tenant = DEFAULT_TENANT
            self.curr_database = self.effective_default_database
        else:
            self.client = self.singleton_client
            self.admin_client = self.singleton_admin_client
            # Set to singleton tenant/database context and update state
            self.client.set_tenant(SINGLETON_TENANT, self.singleton_database)
            self.curr_tenant = SINGLETON_TENANT
            self.curr_database = self.singleton_database

    @overrides
    def set_api_tenant_database(self, tenant: str, database: str) -> None:
        self.client.set_tenant(tenant, database)

    @overrides
    def get_tenant_model(
        self, tenant: str
    ) -> Dict[str, Dict[str, Optional[types.CollectionMetadata]]]:
        if self.client == self.singleton_client:
            tenant = SINGLETON_TENANT
        return self.tenant_to_database_to_model[tenant]

    @overrides
    def set_tenant_model(
        self,
        tenant: str,
        model: Dict[str, Dict[str, Optional[types.CollectionMetadata]]],
    ) -> None:
        if self.client == self.singleton_client:
            # This never happens because we never actually issue a
            # create_tenant call on singleton_tenant:
            # thanks to the above overriding of get_tenant_model(),
            # the underlying state machine test should always expect an error
            # when it sends the request, so shouldn't try to update the model.
            raise ValueError("trying to overwrite the model for singleton??")
        self.tenant_to_database_to_model[tenant] = model

    @overrides
    def set_database_model_for_tenant(
        self,
        tenant: str,
        database: str,
        database_model: Dict[str, Optional[types.CollectionMetadata]],
    ) -> None:
        if self.client == self.singleton_client:
            # This never happens because we never actually issue a
            # create_database call on (singleton_tenant, singleton_database):
            # thanks to the above overriding of has_database_for_tenant(),
            # the underlying state machine test should always expect an error
            # when it sends the request, so shouldn't try to update the model.
            raise ValueError("trying to overwrite the model for singleton??")
        self.tenant_to_database_to_model[tenant][database] = database_model

    @overrides
    def overwrite_database(self, database: str) -> str:
        if self.client == self.singleton_client:
            return self.singleton_database
        return database

    @overrides
    def overwrite_tenant(self, tenant: str) -> str:
        if self.client == self.singleton_client:
            return SINGLETON_TENANT
        return tenant

    @property
    def model(self) -> Dict[str, Optional[types.CollectionMetadata]]:
        # Always use current tenant/database context
        return self.tenant_to_database_to_model[self.curr_tenant][self.curr_database]


def _singleton_and_root_clients(
    database_name: str,
) -> Tuple[Client, Client, ClientFactories]:
    singleton_database = singleton_database_name(database_name)
    api_fixture = fastapi_fixture_admin_and_singleton_tenant_db_user(
        singleton_database=singleton_database
    )
    sys: System = next(api_fixture)
    sys.reset_state()

    # When connecting to external Tilt, also reset the server
    if os.getenv("CHROMA_SERVER_HOST") and not NOT_CLUSTER_ONLY:
        sys.instance(ServerAPI).reset()

    client_factories = ClientFactories(sys)
    root_client = client_factories.create_client(database=database_name)
    root_client.reset()
    _root_admin_client = client_factories.create_admin_client_from_system()

    # This is a little awkward but we have to create the tenant and DB
    # before we can instantiate a Client which connects to them. This also
    # means we need to manually populate state in the state machine.
    _root_admin_client.create_tenant(SINGLETON_TENANT)
    _root_admin_client.create_database(singleton_database, SINGLETON_TENANT)

    singleton_settings = Settings(**dict(sys.settings))
    singleton_settings.chroma_client_auth_credentials = "singleton-token"
    singleton_system = System(singleton_settings)
    singleton_system.start()
    singleton_client = Client.from_system(
        singleton_system, tenant=SINGLETON_TENANT, database=singleton_database
    )

    return singleton_client, root_client, client_factories


@multi_region_test
def test_collections_with_tenant_database_overwrite(
    caplog: pytest.LogCaptureFixture,
    database_name: str,
) -> None:
    caplog.set_level(logging.ERROR)

    singleton_client, root_client, client_factories = _singleton_and_root_clients(
        database_name
    )
    run_state_machine_as_test(
        lambda: SingletonTenantDatabaseCollectionStateMachine(
            singleton_client, root_client, client_factories, database_name
        )
    )  # type: ignore


@multi_region_test
def test_repeat_failure(
    caplog: pytest.LogCaptureFixture,
    database_name: str,
) -> None:
    caplog.set_level(logging.ERROR)

    singleton_client, root_client, client_factories = _singleton_and_root_clients(
        database_name
    )

    state = SingletonTenantDatabaseCollectionStateMachine(
        singleton_client, root_client, client_factories, database_name
    )
    state.initialize()
    state.check_api_and_admin_client_are_in_sync()
    state.change_clients()
    state.check_api_and_admin_client_are_in_sync()
    state.create_coll(
        coll=strategies.Collection(
            name="A00",
            metadata=None,
            embedding_function=strategies.hashing_embedding_function(
                dim=2, dtype=numpy.float16  # type: ignore
            ),
            id=uuid.UUID("c9bcb72f-92b1-4604-a8cb-084162dfe98b"),
            dimension=2,
            dtype=numpy.float16,
            known_metadata_keys={},
            known_document_keywords=[],
            has_documents=False,
            has_embeddings=True,
        )
    )
    state.teardown()  # type: ignore
